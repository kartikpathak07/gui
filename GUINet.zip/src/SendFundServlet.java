

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.techm.dao.BeneficiaryDaoImpl;

/**
 * Servlet implementation class SendFundServlet
 */
public class SendFundServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SendFundServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		HttpSession session =request.getSession(false);
		String m_dbname = (String) request.getSession().getAttribute("a_username");
	String u_name=request.getParameter("usrLoginName");
	long amount=Long.parseLong(request.getParameter("amount"));
	int index=Integer.parseInt(request.getParameter("index"));
	long bAccNo=Long.parseLong(request.getParameter("benefAccNo"));
	BeneficiaryDaoImpl bdao=new BeneficiaryDaoImpl();
	int check=bdao.sendFunds(index,amount,u_name,bAccNo);
	if(check==1)
	{
		RequestDispatcher rd=request.getRequestDispatcher("Success.jsp");
		rd.forward(request, response);
	}
	else
	{
		RequestDispatcher rd=request.getRequestDispatcher("Failure.jsp");
		rd.forward(request, response);
	}
	}

}
