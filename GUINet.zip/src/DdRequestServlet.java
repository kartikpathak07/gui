

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.techm.dao.LoginDaoImpl;

/**
 * Servlet implementation class DdRequestServlet
 */
public class DdRequestServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DdRequestServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		PrintWriter out=response.getWriter();
		HttpSession session =request.getSession(false);
		String m_dbname = (String) request.getSession().getAttribute("a_username");
		String m_accountno=request.getParameter("account");
		System.out.println(m_accountno);
		String m_payee=request.getParameter("payee");
		String mamountno=request.getParameter("amount");
		long m_amount=Long.parseLong(mamountno);
		//String m_accountno=maccountno;
		LoginDaoImpl bdao=new LoginDaoImpl();
		int check=bdao.ddRequest(m_accountno,m_payee,m_amount);
		if(check==0)
		{
			out.print("DemandDraft request SUCCESSFUL");
			RequestDispatcher rd=request.getRequestDispatcher("Success.jsp");
			rd.forward(request, response);
		}
		else
		{
			out.print("wrong account number");
			RequestDispatcher rd=request.getRequestDispatcher("Failure.jsp");
			rd.forward(request, response);
		}
	}

	}


