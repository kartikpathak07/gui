
import java.io.IOException;
import java.io.PrintWriter;

import javax.jms.Session;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.techm.dao.LoginDao;
import com.techm.dao.LoginDaoImpl;

/**
 * Servlet implementation class LoginServlet
 */
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public LoginServlet() {
		super();

	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		System.out.println("YOU ARE IN lOGIN SERVLET");

		response.setContentType("text/html");
		LoginDao loginDao = new LoginDaoImpl();
		PrintWriter out = response.getWriter();
		String m_username = request.getParameter("username");
		String m_password = request.getParameter("password");

		String role = loginDao.validate(m_username, m_password);

		if (role.equals("admin")) {
			System.out.println("going to admin page");
			HttpSession session = request.getSession(true);
			session.setAttribute("a_username", m_username);
			session.setAttribute("a_password", m_password);
			
			RequestDispatcher rd = request
					.getRequestDispatcher("AdminPage.jsp");
			rd.forward(request, response);

			// out.println("Admin logged in ");
		} else if (role.equals("user")) {

			HttpSession session = request.getSession(true);
			session.setAttribute("a_username", m_username);
			session.setAttribute("a_password", m_password);
			out.println("User logged in ");

			RequestDispatcher rd = request.getRequestDispatcher("UserPage.jsp");
			rd.forward(request, response);

		} else {
			 response.sendRedirect("Login.html");
			 
			 
			 
			out.println("Admin logged outttt ");
		}

	}

}
