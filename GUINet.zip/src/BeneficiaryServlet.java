import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import com.techm.dao.BeneficiaryDaoImpl;

/**
 * Servlet implementation class BeneficiaryServlet
 */
public class BeneficiaryServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public BeneficiaryServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		String uname = (String) session.getAttribute("a_username");
		System.out.println(uname);
		request.setAttribute("fname", uname);
		// System.out.println(request.getSession());

		if (request.getSession() != null) {
			BeneficiaryDaoImpl bdao = new BeneficiaryDaoImpl();
			PrintWriter out = response.getWriter();
			response.setContentType("text/html");
			String name = request.getParameter("name");
			String b_acc_no = request.getParameter("b_acc_no");
			long baccno = Long.parseLong(b_acc_no);
			String ifsc = request.getParameter("ifsc");
			int ifs = Integer.parseInt(ifsc);
			int checkUpdate;

		
			checkUpdate = bdao.addBeneficiary(baccno,
					(String) session.getAttribute("a_username"), ifs, name);
			if (checkUpdate == 0) {
				
			
				RequestDispatcher rd = request
						.getRequestDispatcher("Success.jsp");
				rd.forward(request, response);
			} else {
				RequestDispatcher rd = request
						.getRequestDispatcher("Failure.jsp");
				rd.include(request, response);
			}
		}else
			System.out.println("Session is empty");
	}
}
