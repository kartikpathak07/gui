

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.techm.dao.LoginDao;
import com.techm.dao.LoginDaoImpl;

import com.techm.dao.UserDetailsDaoImpl;
import com.techm.dto.Login;
import com.techm.dto.UserDetails;
import com.techm.dao.UserDetailsDao;

/**
 * Servlet implementation class InsertUserServlet
 */
public class InsertUserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public InsertUserServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String m_name=request.getParameter("name");
		String m_uname=request.getParameter("uName");
		String manumb=request.getParameter("aNumber");
		long m_anumb=Long.parseLong(manumb);
		String mbal=request.getParameter("bal");
		long m_bal=Long.parseLong(mbal);
		String m_contact=request.getParameter("contact");
		long m_cont=Long.parseLong(m_contact);
		String m_address=request.getParameter("address");
		String m_email=request.getParameter("email");
		String m_password=request.getParameter("password");
		String m_atype=request.getParameter("atype");
		UserDetails user=new UserDetails(m_name,m_uname,m_anumb,m_bal,m_cont,m_address,m_email,m_password,m_atype);
		UserDetailsDaoImpl userDao=new UserDetailsDaoImpl();
		if(userDao.insertrec(user))
		{
			out.println("RECORD INSERTED SUCCESSFULLY");
		}
		else
		{
			out.println("RECORD NOT INSERTED");
		}
		Login log=new Login(m_name,m_password);
		LoginDao ld=new LoginDaoImpl();
		if(ld.insertrec(log))
		{
			out.println("INSERTED");
		}
		else
		{
			out.println("UNAME PASSWORD ALREADY EXISTS");
		}
	}

}
