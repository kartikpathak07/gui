

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.techm.dao.BeneficiaryDaoImpl;
import com.techm.dto.Details;

/**
 * Servlet implementation class ActivateChequeServlet
 */
public class ActivateChequeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ActivateChequeServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("In activate chequebookservlet");
		HttpSession session = request.getSession();
		String uname = (String) session.getAttribute("a_username");
		
		BeneficiaryDaoImpl bdao = new BeneficiaryDaoImpl();
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		BeneficiaryDaoImpl bdao1 = new BeneficiaryDaoImpl();
		Details dt= new Details();
		//String id=request.getParameter("value");
		String cid=request.getParameter("value1");
		
		String chkid=request.getParameter("chkId");
		long cAcNo=Long.parseLong(request.getParameter("chkAccNo"));
		
		System.out.println(chkid);
		System.out.println(cAcNo);
		
		
		int check=bdao1.approveCheque(chkid,cAcNo);
		if(check==1)
		{
			System.out.println("CHEQUE APPROVED");
			RequestDispatcher rd=request.getRequestDispatcher("AdminPage.jsp");
			rd.forward(request, response);
		}
		else
		{
			System.out.println("NOT UPDATED");
		}
		
	
	}
}
