package com.techm.dao;

import com.techm.dto.UserDetails;

public interface UserDetailsDao 
{
	boolean insertrec(UserDetails user);
}
