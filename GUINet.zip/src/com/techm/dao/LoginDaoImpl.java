package com.techm.dao;




import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.io.PrintWriter;



import com.sun.mail.iap.Response;
import com.techm.dto.Information;
import com.techm.dto.Login;
import com.techm.util.JdbcConnection;

public class LoginDaoImpl implements LoginDao
{
	
	public String validate(String username,String password) 

	{
		Connection conn=null;
		conn=JdbcConnection.getConnection();
		PreparedStatement pst=null;
		String role=null;
		String query= "select * from banklogin where username=? and password=?";
		
		try {
			pst=conn.prepareStatement(query);
			pst.setString(1, username);
			pst.setString(2, password);
			
			ResultSet rs  = pst.executeQuery();
			
			if(rs.next()== true){
				role=rs.getString(3);
				return role;
			}else
			{
			
				role="notavailable";
			return role;
			}
			
		} 
		catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				conn.close();
			} 
			catch (SQLException e) 
			{
				e.printStackTrace();
			}
		}
		return role;
	}
	//METHOD TO UPDATE ADMIN PASSWORD
	public String updatePassword(String m_dbname, String oldpassword,
			String newpassword, String verifypassword)
	{
		String stat=null;
		Connection conn=null;
		conn=JdbcConnection.getConnection();
		PreparedStatement pst=null;
		System.out.println("hello IN update password page");
		
		String query= "select * from banklogin where username=?";
		
			try 
			{
				
				
				pst=conn.prepareStatement(query);
				pst.setString(1,m_dbname);
				
				ResultSet rec= pst.executeQuery();
				
				while(rec.next())
				{
				
					String tempUsername = rec.getString(1);
					String dbpassword=rec.getString(2);
					//System.out.println(dbpassword);
					if(oldpassword.equals(dbpassword))
					{
						if(newpassword.equals(verifypassword))
						{
							//System.out.println("IF Bolck execites");
							String query1=" update banklogin set password=? where username=?";
							PreparedStatement pst1=conn.prepareStatement(query1);
		
							pst1.setString(1, newpassword);
							pst1.setString(2, tempUsername);
							
							pst1.executeUpdate();
							System.out.println("Password changed");
							stat="pass";
						}
				
						else
						{
						stat="fail";
						}
					
					}
					else
					{
						stat="fail";
					}
				}
			} 
			catch (SQLException e) 
			{
				e.printStackTrace();
			}
			finally
			{
				try 
				{
					conn.close();
				} 
				catch (SQLException e) 
				{
					e.printStackTrace();
				}
			}
			return stat;
		
		}
		
		public boolean insertrec(Login login) 
		{
		Connection conn=null;
		conn=JdbcConnection.getConnection();
		PreparedStatement pst=null;
		String query="INSERT INTO BANKLOGIN VALUES(?,?,?)";
		try 
		{
			pst=conn.prepareStatement(query);
			pst.setString(1,login.getUsername());
			pst.setString(2,login.getPassword());
			pst.setString(3,"user");
			int rec=pst.executeUpdate();
			if(rec==1)
			{
				return true;
			}
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		return false;
	}

	
	 {
	
	}


	@Override
	public long viewBalance(String username) 
	{
		long balance=0;
		Connection conn=null;
		conn=JdbcConnection.getConnection();
		PreparedStatement pst=null;
		String query="SELECT * FROM BANKUSER WHERE USERNAME=?";
		try {
			System.out.println(username);
			
			pst=conn.prepareStatement(query);
			pst.setString(1,username);
			
			ResultSet rs= pst.executeQuery();
			if(rs.next()==true)
			{	
				System.out.println("IF WORKING");
				balance=rs.getLong(4);
				return balance;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
		
		
		
		
	}


	public List<Information> updateProfile(String username) {
		// TODO Auto-generated method stub
		
		
		Connection conn=null;
		conn=JdbcConnection.getConnection();
		PreparedStatement pst=null;
		
		ArrayList<Information> contents = new ArrayList<Information>();
		String query= "select * from BankUser where username=?";
		try {
			
			pst=conn.prepareStatement(query);
			pst.setString(1, username);
			 ResultSet rs=pst.executeQuery();
			System.out.println(username);
			
			
			if(rs.next()==true)
			{
			
				String custname=rs.getString(3);
				String address=rs.getString(6);
				long contactno=rs.getLong(7);
				String emailid=rs.getString(8);
				
				Information inf = new Information(custname,address, contactno,emailid);
				contents.add(inf);
			}
			else
			{
				System.out.println("data ot found");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
		return contents;
		
		
	}
	public int updateProfileData(String dbname,String address,long contactno,String email)
	{
		int i=0;
		Connection conn=null;
		conn=JdbcConnection.getConnection();
		PreparedStatement pst=null;
		
	
		String query= "UPDATE BankUser SET address=?,phone_no=?,email=? where username=?";
		
		try {
			pst=conn.prepareStatement(query);
			
			pst.setString(1,address);
			pst.setLong(2, contactno);
			pst.setString(3,email);
			pst.setString(4, dbname);
			System.out.println("Update Working");
			int rs=pst.executeUpdate();
			if(rs==1)
			{
				 i=1;
			}
			else 
			{
				
				i=0;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally
		{
			try 
			{
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
		return i;
		
	}
	public int chequeRequest(long account_no) 
			{
			int i=1;
			int rand=(int) (Math.random()*1000);
			String cheque_no=""+rand;
			Connection conn=null;
			conn=JdbcConnection.getConnection();
			String query= "insert into ChequeBook values(?,?,?)";
			try {
			PreparedStatement pst= conn.prepareStatement(query);
			pst.setString(1,cheque_no);
			pst.setLong(2,account_no);
			pst.setString(3,"REQUESTED");
			int updateCount=pst.executeUpdate();
			if(updateCount>0)
			i=0;
			else
			i=1;
			} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			}
			finally
			{
			try {
			conn.close();
			} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			}
			}
			return i;
			}
	public int ddRequest(String account_no, String payee,long amount) 
	{
	int i=1;
	int rand=(int) (Math.random()*1000);
	String ddno=""+rand;
	Connection conn=null;
	conn=JdbcConnection.getConnection();
	String query= "insert into demanddraft values(?,?,?,sysdate,?,?)";
	try {
	PreparedStatement pst= conn.prepareStatement(query);
	pst.setString(1,ddno);
	pst.setString(2,account_no);
	pst.setString(3, payee);
	pst.setLong(4, amount);
	pst.setString(5, "Requested");
	
	int updateCount=pst.executeUpdate();
	if(updateCount>0)
	i=0;
	else
	i=1;
	} catch (SQLException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
	}
	finally
	{
	try {
	conn.close();
	} catch (SQLException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
	}
	}
	return i;
	}

	
	
}

	


