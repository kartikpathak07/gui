package com.techm.dao;

import java.util.ArrayList;

import com.techm.dto.Login;

public interface LoginDao 
{
	String validate(String username,String password);
	String updatePassword(String m_dbpassword,String oldpassword,String newpassword,String verifypassword);
	boolean insertrec(Login log);
	long viewBalance(String username);
//ArrayList List<Information> updateProfile(String username);
}
