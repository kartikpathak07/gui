package com.techm.dto;

public class Beneficiary 
{


private long account_no;
private String username;
private int ifsc;
private String activstat;
private String approval;
private String benname;
private String bid;
@Override
public String toString() {
	return "Beneficiary [account_no=" + account_no + ", username=" + username
			+ ", ifsc=" + ifsc + ", activstat=" + activstat + ", approval="
			+ approval + ", benname=" + benname + ", bid=" + bid + "]";
}
public Beneficiary(long account_no, String username, int ifsc,
		String activstat, String approval, String benname, String bid) {
	super();
	this.account_no = account_no;
	this.username = username;
	this.ifsc = ifsc;
	this.activstat = activstat;
	this.approval = approval;
	this.benname = benname;
	this.bid = bid;
}
public Beneficiary() {
	super();
}
public long getAccount_no() {
	return account_no;
}
public void setAccount_no(long account_no) {
	this.account_no = account_no;
}
public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public int getIfsc() {
	return ifsc;
}
public void setIfsc(int ifsc) {
	this.ifsc = ifsc;
}
public String getActivstat() {
	return activstat;
}
public void setActivstat(String activstat) {
	this.activstat = activstat;
}
public String getApproval() {
	return approval;
}
public void setApproval(String approval) {
	this.approval = approval;
}
public String getBenname() {
	return benname;
}
public void setBenname(String benname) {
	this.benname = benname;
}
public String getBid() {
	return bid;
}
public void setBid(String bid) {
	this.bid = bid;
}

 
}